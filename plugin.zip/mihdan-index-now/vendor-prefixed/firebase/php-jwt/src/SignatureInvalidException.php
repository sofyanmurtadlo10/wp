<?php

namespace Mihdan\IndexNow\Dependencies\Firebase\JWT;

/** @internal */
class SignatureInvalidException extends \UnexpectedValueException
{
}
