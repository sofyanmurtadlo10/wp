<?php

namespace Mihdan\IndexNow\Dependencies\GuzzleHttp\Exception;

/** @internal */
class TransferException extends \RuntimeException implements GuzzleException
{
}
