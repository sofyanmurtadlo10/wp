<?php

namespace Mihdan\IndexNow\Dependencies\GuzzleHttp\Exception;

use Mihdan\IndexNow\Dependencies\Psr\Http\Client\ClientExceptionInterface;
/** @internal */
interface GuzzleException extends ClientExceptionInterface
{
}
