<?php

namespace Mihdan\IndexNow\Dependencies\GuzzleHttp\Exception;

/** @internal */
class TooManyRedirectsException extends RequestException
{
}
