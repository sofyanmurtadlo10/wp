<?php

namespace Mihdan\IndexNow\Dependencies\GuzzleHttp\Exception;

/** @internal */
final class InvalidArgumentException extends \InvalidArgumentException implements GuzzleException
{
}
