<?php

namespace Mihdan\IndexNow\Dependencies\Carbon\Doctrine;

/** @internal */
class CarbonImmutableType extends DateTimeImmutableType implements CarbonDoctrineType
{
}
