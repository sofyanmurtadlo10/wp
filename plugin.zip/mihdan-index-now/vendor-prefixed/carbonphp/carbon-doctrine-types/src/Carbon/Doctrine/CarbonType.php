<?php

namespace Mihdan\IndexNow\Dependencies\Carbon\Doctrine;

/** @internal */
class CarbonType extends DateTimeType implements CarbonDoctrineType
{
}
