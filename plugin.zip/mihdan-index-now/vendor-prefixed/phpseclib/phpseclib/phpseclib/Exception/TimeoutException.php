<?php

namespace Mihdan\IndexNow\Dependencies\phpseclib3\Exception;

/**
 * Indicates a timeout awaiting server response
 * @internal
 */
class TimeoutException extends \RuntimeException
{
}
