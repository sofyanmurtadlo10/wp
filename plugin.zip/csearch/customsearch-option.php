<?php 
function csearch_header(){
	$content = "<link rel=\"stylesheet\" href=\"".CSEARCH_PLUGIN_URL."/admin.css\" />
        <style type=\"text/css\">
            #container {
                width: 100%;
                padding-right: 10px;
                font-size: 13px;
                font-family: Arial;
                line-height: 2;
                float: left;
				min-height:400px;
            }
            .normalize {
                margin-bottom: 0px !important;
                padding-bottom: 0px !important;
                height: 53px !important;
                font-size: 12px;
                font-weight:bolder;
            }
            .normalize > li > a {
                text-decoration: none !important;
                color: #222 !important;
            }
            .normalize > li > a:hover {
                background-color: transparent !important;
            }
            select{
                height:38px !important;
            }
        </style>
	<body style=\"background-color: #f1f1f1 !important;\">
		<div class=\"container\" style=\"background-color: #f1f1f1 !important;margin-right: 10px !important;\">
	    <div class=\"container\">
	        <hr style=\"border: 20px solid #222; margin-left: 15px; margin-right: 15px; margin-top: 30px; margin-bottom: 0px !important;\">
            <hr style=\"border: 2px solid #e6e6e6; margin-left: 15px; margin-right: 15px; margin-top: 0px !important; margin-bottom: 0px;\">";
	return $content;
}
function csearch_sidebar(){
    $content = "<div class=\"callout secondary error\">
		<p>Saat ini anda menggunakan : 
			<b>Plugin Version ".CSEARCH_VERSION." </b><br>
			<b></b>
			<br/> Jika terjadi kendala silahkan hubungi kami melalui helpdesk.
		</p>
		<a href=\"http://www.idscripts.com/member/helpdesk\" class=\"button button-primary\" style=\"margin-bottom:8px\" target=\"_blank\">Helpdesk</a>
	</div>
	<div style=\"clear: both\"></div>
	<br/>";
   return $content;
}
function csearch_footer(){
	$content = "<div style=\"clear: both !important;\"></div>
            <hr style=\"border: 2px solid #e6e6e6; margin-left: 15px; margin-right: 15px; margin-bottom: 0px;\">
			<div class=\"row\">
				<div class=\"large-12 columns\">
					<center>
						<p>Visit : <a target='_blank' href='http://www.idscripts.com'>Our Homepage</a></p>
					</center>
				</div>
			</div>
            <hr style=\"border: 20px solid #222; margin-left: 15px; margin-right: 15px; margin-top: 0px !important; margin-bottom: 30px;\">
        </div>
		<script type=\"text/javascript\">
			 $(document).foundation();
		</script>
    </body>";
	return $content;
}

function csearch_settings() {	
	echo csearch_header();		
	$set = get_option('csearch_options'); 
	if ( @$_REQUEST["saved"] ){
		$content = "<div id=\"message\" class=\"updated fade below-h2\" style=\"margin-bottom: 20px;\"><p><strong>Custom Search Permalink Settings Saved.</strong></p></div>";
	}
	$set = get_option('csearch');
	$content .= "<form method=\"post\" action=\"\">
		<div style=\"float: left;\">
			<div style=\"margin-left: 15px !important;\">
				<h1>Custom Search Permalink Settings</h1>
			</div>
		</div>
		<div style=\"clear: both !important;\"></div>
		<div class=\"large-8 medium-8 columns\">
			<ul class=\"tabs normalize\" data-tabs id=\"example-tabs\">
				<li class=\"tabs-title is-active\">
					<a href=\"#panel1\" aria-selected=\"true\">General Options</a>
				</li>	
			</ul>
			<div class=\"tabs-content\" data-tabs-content=\"example-tabs\">
				<div class=\"tabs-panel is-active\" id=\"panel1\">
					<div class=\"row\">
						<div style=\"clear: both;\"></div>
						<div class=\"small-3 columns\">
							<span data-tooltip aria-haspopup=\"true\" class=\"has-tip text-right middle\" data-options=\"show_on:large\" title=\"Please devine the search base ?\" style=\"font-size:12px\">Search Base</span>
						</div>
						<div class=\"small-2 columns\">
							<select style=\"font-size:12px\" name=\"csearch[base]\" id=\"csearch[base]\">
								<option value=\"first\"".(($set['base'] == "first")?"selected":"").">First Word</option>
								<option value=\"custom\"".(($set['base'] == "custom")?"selected":"").">Custom Base</option>
							</select>
						</div>
						<p style=\"margin-left: 15px !important;\">
							http://www.yourdomain.com/<b>".(($set['base']=="")?"search": $set['base'])."</b>/keyword-query-search
						</p>
						<div style=\"clear: both;\"></div>
						<div class=\"small-3 columns\">
							<span data-tooltip aria-haspopup=\"true\" class=\"has-tip text-right middle\" data-options=\"show_on:large\" title=\"Please devine the search base custom ?\" style=\"font-size:12px\">Search Base Custom</span>
						</div>
						<div class=\"small-2 columns\">
							<input type=\"text\" name=\"csearch[custom]\" id=\"csearch[custom]\" style=\"font-size:12px\" value=\"".(($set['custom']=="")?"search": $set['custom'])."\">
						</div>
						<div style=\"clear: both;\"></div>
						<div class=\"small-3 columns\">
							<span data-tooltip aria-haspopup=\"true\" class=\"has-tip text-right middle\" data-options=\"show_on:large\" title=\"Please devine the search structure ?\" style=\"font-size:12px\">Search Structure</span>
						</div>
						<div class=\"small-2 columns\">
							<input type=\"text\" name=\"csearch[structure]\" id=\"csearch[structure]\" style=\"font-size:12px\" value=\"".(($set['structure']=="")?"%search%": $set['structure'])."\">
						</div>
						<p style=\"margin-left: 15px !important;\">
							http://www.yourdomain.com/".(($set['base']=="")?"search": $set['base'])."/<b>".(($set['structure']=="")?"%search%": $set['structure'])."</b>
						</p>
						<div style=\"clear: both;\"></div>
						<p style=\"margin-left: 15px !important;\">
							Do not change the %search%, you may change to %search%.html or etc.
						</p>
						<div style=\"clear: both;\"></div>
						<br/>
						<div class=\"small-3 columns\">
							<span data-tooltip aria-haspopup=\"true\" class=\"has-tip text-right middle\" data-options=\"show_on:large\" title=\"Please devine the search base ?\" style=\"font-size:12px\">Validate Search Query</span>
						</div>
						<div class=\"small-2 columns\">
							<select style=\"font-size:12px\" name=\"csearch[validate]\" id=\"csearch[validate]\">
								<option value=\"novalid\"".(($set['validate'] == "novalid")?"selected":"").">No Validation</option>
								<option value=\"2words\"".(($set['validate'] == "2words")?"selected":"").">2 Words And More</option>
								<option value=\"3words\"".(($set['validate'] == "3words")?"selected":"").">3 Words And More</option>
								<option value=\"4words\"".(($set['validate'] == "4words")?"selected":"").">4 Words And More</option>
							</select>
						</div>
						<div style=\"clear: both;\"></div>
						<p style=\"margin-left: 15px !important;\">If it meets with validation then it will be directed to Home URL.</p>
						
					</div>
				</div>
			</div>
		</div>
		<div class=\"large-4 medium-4 columns\">".csearch_sidebar()."</div>
		<div style=\"clear: both !important;\"></div>
		<div style=\"float: left;\">
			<div style=\"margin-top: 20px !important; margin-left: 15px !important; margin-bottom: 20px !important;\">
				<input name=\"save\" type=\"submit\" class=\"button-primary\" value=\"Save Changes\">
				<input type=\"hidden\" name=\"action\" value=\"save\">
			</div>
		</div>
	</form>";
	echo $content;
	echo csearch_footer();
}
function csearch_add_page() {
	if ("save" == @$_REQUEST["action"] ) {
        update_option('csearch', $_REQUEST['csearch']);
		echo "<script> window.location = \"options-general.php?page=csearch&saved=true\"</script>";
		die;
    }
	add_options_page( "Custom Search Permalink", __("Custom Search Link", "csearch"), "manage_options", "csearch", "csearch_settings", "dashicons-album" );
	
}
add_action( 'admin_menu', 'csearch_add_page' );