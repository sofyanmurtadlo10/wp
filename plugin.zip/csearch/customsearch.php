<?php
/*
Plugin Name: Custom Search Permalink
Plugin URI: http://www.idscripts.com
Description: Change Search Permalink.
Author: Ari Artama
Version: 1.0.0
Author URI: http://www.facebook.com/ariartama
*/

define( "CSEARCH_VERSION", "1.0.0" );
define( "CSEARCH_PLUGIN_URL", plugin_dir_url( __FILE__ ) );
define( "CSEARCH_PLUGIN_DIR", plugin_dir_path( __FILE__ ) );
//Auto update plugin checker
require_once( CSEARCH_PLUGIN_DIR . "src/plugin-update-checker/plugin-update-checker.php" );
$MyUpdateChecker = PucFactory::buildUpdateChecker("http://www.idscripts.com/plugins/csearch/?action=metadata&slug=csearch", __FILE__,"csearch");

if(is_admin()) include_once("customsearch-option.php");
function csearch_search_rewrite_rule() {
	if ( is_search() && !empty($_GET['s'])) {
		if(csearch_validation($_GET['s'])){
			$set = get_option('csearch');
			$base = $set['base'];
			$custom = $set['custom'];
			$structure = $set['structure'];
			if($base=="first"){
				$result = explode(' ',trim($_GET['s']));
				$permastruct = strtolower($result[0]);
			}else{
				$permastruct = $custom;
			}
			$ganti = array('+',' '); //tanda plus dan spasi
			//$searchquery = user_trailingslashit(urlencode($_GET['s']));//str_replace($ganti, '-' ,user_trailingslashit(urlencode($_GET['s'])));
			$searchquery = sanitize_title(strtolower(str_replace($ganti, '-' ,user_trailingslashit(urlencode($_GET['s'])))));
			$structure = str_replace("%search%",$searchquery,$structure);
			wp_redirect(home_url($permastruct."/") . $structure);
			exit();
		}else{
			wp_redirect(home_url());
			exit();
		}
	}
	
}
add_action('template_redirect', 'csearch_search_rewrite_rule');	

function csearch_stt2_title_uri($idx=1){
    $permalink  = $_SERVER["REQUEST_URI"];
    $permalinkx = $_SERVER["REQUEST_URI"];
    $permalinky = explode("?",$permalink);
    $permalinky = $permalinky[0];
    $permalink  = explode("/",$permalinkx);
    $permalinkz = $permalink[$idx];
    $permalink  = $permalink[$idx];
    $permalink  = explode("?",$permalink);
    $permalink  = $permalink[0];
    $permalink  = urldecode(str_replace(array(".","/","-","+","-","%7C","jpg","php","gif","aspx","html","Blogspot","Com",".com","http","Wikipedia")," ",$permalink));
    return $permalink;
}
function csearch_set_stt2_permalink(){
	$set = get_option('csearch');
	$base = $set['base'];
	$custom = $set['custom'];
	$structure = $set['structure'];
	if($base=="first"){
		$alluri = csearch_stt2_title_uri();
		$geturi = csearch_stt2_title_uri(2);
		$result = explode(' ',trim($geturi));
		$permastruct = strtolower($result[0]);
		
		if(!empty($alluri) && !empty($geturi)){
			if($alluri==$permastruct){
				if(csearch_validation($geturi)){
					$GLOBALS['wp_rewrite']->search_base = $permastruct;
					$GLOBALS['wp_rewrite']->search_structure = $GLOBALS['wp_rewrite']->root . $permastruct .'/'.$structure;
					$GLOBALS['wp_rewrite']->flush_rules();
				}else{
					wp_redirect(home_url());
					exit();
				}				
			}
		}
	}else{
		$permastruct = $custom;
		$GLOBALS['wp_rewrite']->search_base = $permastruct;
		$GLOBALS['wp_rewrite']->search_structure = $GLOBALS['wp_rewrite']->root . $permastruct .'/'.$structure;
		$GLOBALS['wp_rewrite']->flush_rules();
	}	
	
}
add_action('init', 'csearch_set_stt2_permalink');

function csearch_validation($searchquery){
	$set = get_option('csearch');
	$validate = $set['validate'];
	if($validate=="novalid"){
		return true;
	}else{
		if($validate=="2words"){
			
			$result = explode(' ',trim($searchquery));
			if(count($result)>=2){
				return true;
			}else{
				return false;
			}
		}else if($validate=="3words"){
			$result = explode(' ',trim($searchquery));
			if(count($result)>=3){
				return true;
			}else{
				return false;
			}
		}else if($validate=="4words"){
			$result = explode(' ',trim($searchquery));
			if(count($result)>=4){
				return true;
			}else{
				return false;
			}
		}
	}
}

function csearch_pre_get_post( $query ) {
	if ( ! $query->is_main_query() || ! $query->is_search() ){
        return;
	}
	
	$ganti = array('-','+');	
	$searchquery = ucwords(str_replace($ganti, ' ' ,$query->get( 's' )));
	
	$alluri = csearch_stt2_title_uri();
	$geturi = csearch_stt2_title_uri(2);
	$result = explode(' ',trim($geturi));
	$permastruct = strtolower($result[0]);
	
	if(!empty($alluri) && !empty($geturi)){
		if($alluri==$permastruct){
			$searchquery = str_replace(array('/',$alluri),"",$searchquery);
		}
	}
    $query->set( 's', $searchquery);
}

add_action( 'pre_get_posts', 'csearch_pre_get_post');
?>