<?php
add_action('admin_menu', 'kkc_bibitws_menu');
function kkc_bibitws_menu() {
	add_menu_page('Kembali ke Cuan (firmanthok.com)', 'Kembali Cuan', 'administrator', 'kkcBws', 'kkc_set_page', 'dashicons-image-rotate-left');
	add_action( 'admin_init', 'register_kkc_set' );
}
function register_kkc_set() {
	register_setting( 'kkc_set_opsi', 'kkc_scr' );
	register_setting( 'kkc_set_opsi', 'kkc_lokasi' );
	register_setting( 'kkc_set_opsi', 'kkcAff1' );
	register_setting( 'kkc_set_opsi', 'kkcAff2' );
	register_setting( 'kkc_set_opsi', 'kkcAff3' );
}
function kkc_set_page() { ?>
	<div class="wrap">
		<h2>Script Kembali Jadi Cuan (firmanthok.com)</h2>
		<hr/>
		<form method="post" action="options.php">
		<?php settings_fields( 'kkc_set_opsi' ); ?>
		<?php do_settings_sections( 'kkc_set_opsi' ); ?>
		<table class="form-table">
			<tr valign="top">
				<th scope="row">LINK AFILIASI / IKLAN<br/><em style="color:green">(Link akan tampil acak)</em></th>
				<td>
					1: <input type="text" value="<?php echo esc_attr(get_option('kkcAff1')); ?>" name="kkcAff1" /> <em style="color:red">(Wajib Diisi!)</em><br/>
					2: <input type="text" value="<?php echo esc_attr(get_option('kkcAff2')); ?>" name="kkcAff2" /><br/>
					3: <input type="text" value="<?php echo esc_attr(get_option('kkcAff3')); ?>" name="kkcAff3" />
				</td>
			</tr>
			<tr valign="top">
				<th scope="row">PILIH SCRIPT</th>
				<td>
					<select name="kkc_scr">
						<option value="1" <?php if(esc_attr(get_option('kkc_scr'))==1 || esc_attr(get_option('kkc_scr'))===false || esc_attr(get_option('kkc_scr'))=="") echo "selected=\"selected\""; ?>>Versi #1</option>
						<option value="2" <?php if(esc_attr(get_option('kkc_scr'))==2) echo "selected=\"selected\""; ?>>Versi #2</option>
					</select>
				</td>
			</tr>
			<tr valign="top">
				<th scope="row">LOKASI PASANG SCRIPT</th>
				<td>
					<select name="kkc_lokasi">
						<option value="1" <?php if(esc_attr(get_option('kkc_lokasi'))==1) echo "selected=\"selected\""; ?>>Header</option>
						<option value="0" <?php if(esc_attr(get_option('kkc_lokasi'))==0 || esc_attr(get_option('kkc_lokasi'))===false || esc_attr(get_option('kkc_lokasi'))=="") echo "selected=\"selected\""; ?>>Footer</option>
					</select>
				</td>
			</tr>
		</table>
		<?php submit_button(); ?>
		</form>
	</div>
<?php
}
function kkc_bws(){
	$kkcLink123 = array(esc_attr(get_option('kkcAff1')),esc_attr(get_option('kkcAff2')),esc_attr(get_option('kkcAff3')));
	$kkcLinkRnd = $kkcLink123[array_rand($kkcLink123, 1)]; 
	if (!empty($kkcLinkRnd)){
		$kkcLinkAff=$kkcLinkRnd;
	} else { $kkcLinkAff=esc_attr(get_option('kkcAff1')); }
	if(esc_attr(get_option('kkc_scr'))==1 || esc_attr(get_option('kkc_scr'))===false || esc_attr(get_option('kkc_scr'))==""){
		echo '<script type="text/javascript" language="javascript">(function(window, location) { history.replaceState(null, document.title, location.pathname+"#!/history"); history.pushState(null, document.title, location.pathname); window.addEventListener("popstate", function() { if(location.hash === "#!/history") { history.replaceState(null, document.title, location.pathname); setTimeout(function(){ location.replace("'. $kkcLinkAff .'"); },10); } }, false); }(window, location));</script>';
	}
	elseif(esc_attr(get_option('kkc_scr'))==2){
		echo '<script type="text/javascript" language="javascript">history.pushState(null, document.title, window.location.href); window.addEventListener("popstate", function (event){ window.location.href="'. $kkcLinkAff .'"; }); window.addEventListener("scroll", function() { history.pushState(null, document.title, window.location.href); }); function isUrl(data){ try{ new URL(data); return true; }catch(e){ return false; }; };</script>';
	}
	else {
		echo '<script type="text/javascript" language="javascript">(function(window, location) { history.replaceState(null, document.title, location.pathname+"#!/history"); history.pushState(null, document.title, location.pathname); window.addEventListener("popstate", function() { if(location.hash === "#!/history") { history.replaceState(null, document.title, location.pathname); setTimeout(function(){ location.replace("'. $kkcLinkAff .'"); },10); } }, false); }(window, location));</script>'; // default script#1
	}
}
if(esc_attr(get_option('kkc_lokasi'))==0 || esc_attr(get_option('kkc_lokasi'))===false || esc_attr(get_option('kkc_lokasi'))==""){
	add_action('wp_footer', 'kkc_bws');
} elseif(esc_attr(get_option('kkc_lokasi'))==1){
	add_action('wp_head', 'kkc_bws');
}
// EOF: dev by Bibit.WS