<?php
/* *
	Kembali ke Cuan
	Script original oleh firmanthok.com
	Dipluginkan oleh https://bibit.ws/plugin/
*/