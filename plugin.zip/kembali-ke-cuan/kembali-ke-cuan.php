<?php
/**
* Plugin Name: Kembali ke Cuan (firmanthok.com)
* Description: Maksimalkan Trafik Menjadi Cuan. Script original oleh firmanthok.com
* Version: 1.0
* Author: Firman Syah
* Author URI: https://firmanthok.com/
* Plugin URI: https://bibit.ws/plugin/
*/

if ( ! defined( 'ABSPATH' ) ) exit;

function kkc_aktivasi( $plugin ) {
    if( $plugin == plugin_basename( __FILE__ ) ) {
        exit( wp_redirect( admin_url( 'admin.php?page=kkcBws' ) ) );
    }
}
add_action( 'activated_plugin', 'kkc_aktivasi' );
function kkc_set_link( $links ) {
    $settings_link = '<a href="admin.php?page=kkcBws">' . __( 'Settings' ) . '</a>';
    array_push( $links, $settings_link );
  	return $links;
}
$plugin = plugin_basename( __FILE__ );
add_filter( "plugin_action_links_$plugin", 'kkc_set_link' );
require_once 'kkc-bibit.ws-plugin.php';
// EOF