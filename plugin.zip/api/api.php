<?php
/**
 * Plugin Name: Custom API
 * Description: Plugin untuk meregistrasi metadata kustom: rank_math_focus_keyword, hd_video (on/off), tracking_url, dan embed agar dapat diposting melalui REST API.
 * Version: 1.0.1
 * Author: Showpen
 * License: GPL v2 or later
 * Text Domain: custom-metadata-api-registrar
 */

// Pastikan tidak ada akses langsung
if (!defined('ABSPATH')) {
    exit;
}

class CustomMetadataAPIRegistrar {
    
    public function __construct() {
        add_action('init', array($this, 'register_custom_metadata'));
        add_action('rest_api_init', array($this, 'register_rest_api_fields'));
    }
    
    /**
     * Registrasi metadata kustom
     */
    public function register_custom_metadata() {
        $post_types = get_post_types(array('public' => true));
        
        foreach ($post_types as $post_type) {
            // Register rank_math_focus_keyword
            register_post_meta($post_type, 'rank_math_focus_keyword', array(
                'type' => 'string',
                'description' => 'Focus keyword untuk Rank Math SEO',
                'single' => true,
                'show_in_rest' => true,
                'sanitize_callback' => 'sanitize_text_field',
                'auth_callback' => function() {
                    return current_user_can('edit_posts');
                }
            ));
            
            // Register hd_video sebagai string (on/off)
            register_post_meta($post_type, 'hd_video', array(
                'type' => 'string',
                'description' => 'Status video kualitas tinggi (on/off)',
                'single' => true,
                'show_in_rest' => true,
                'sanitize_callback' => array($this, 'sanitize_hd_video'),
                'auth_callback' => function() {
                    return current_user_can('edit_posts');
                }
            ));
            
            // Register tracking_url
            register_post_meta($post_type, 'tracking_url', array(
                'type' => 'string',
                'description' => 'URL untuk tracking',
                'single' => true,
                'show_in_rest' => true,
                'sanitize_callback' => 'esc_url_raw',
                'auth_callback' => function() {
                    return current_user_can('edit_posts');
                }
            ));
            
            // Register embed
            register_post_meta($post_type, 'embed', array(
                'type' => 'string',
                'description' => 'Kode embed (iframe atau script)',
                'single' => true,
                'show_in_rest' => true,
                'sanitize_callback' => array($this, 'sanitize_embed'),
                'auth_callback' => function() {
                    return current_user_can('edit_posts');
                }
            ));
        }
    }
    
    /**
     * Sanitize nilai hd_video (on/off)
     */
    public function sanitize_hd_video($value) {
        if ($value === 'on' || $value === 'off') {
            return $value;
        }
        
        // Konversi nilai boolean atau angka ke string on/off
        if ($value === true || $value === 'true' || $value === '1' || $value === 1) {
            return 'on';
        }
        
        return 'off'; // Default ke off
    }
    
    /**
     * Sanitize kode embed
     */
    public function sanitize_embed($embed_code) {
        // Izinkan tag iframe dan parameter tertentu untuk embed
        $allowed_html = array(
            'iframe' => array(
                'src' => array(),
                'width' => array(),
                'height' => array(),
                'frameborder' => array(),
                'allowfullscreen' => array(),
                'loading' => array(),
                'allow' => array(),
                'style' => array(),
                'class' => array(),
                'id' => array(),
            ),
            'script' => array(
                'src' => array(),
                'async' => array(),
                'defer' => array(),
                'type' => array(),
            ),
            'div' => array(
                'class' => array(),
                'id' => array(),
                'style' => array(),
                'data-*' => array(),
            ),
        );
        
        return wp_kses($embed_code, $allowed_html);
    }
    
    /**
     * Registrasi field untuk REST API
     */
    public function register_rest_api_fields() {
        $post_types = get_post_types(array('public' => true));
        
        foreach ($post_types as $post_type) {
            // Register field untuk rank_math_focus_keyword
            register_rest_field($post_type, 'rank_math_focus_keyword', array(
                'get_callback' => function($post_arr) {
                    return get_post_meta($post_arr['id'], 'rank_math_focus_keyword', true);
                },
                'update_callback' => function($value, $post) {
                    update_post_meta($post->ID, 'rank_math_focus_keyword', sanitize_text_field($value));
                },
                'schema' => array(
                    'description' => 'Focus keyword untuk Rank Math SEO',
                    'type' => 'string',
                    'context' => array('view', 'edit'),
                ),
            ));
            
            // Register field untuk hd_video (string on/off)
            register_rest_field($post_type, 'hd_video', array(
                'get_callback' => function($post_arr) {
                    $value = get_post_meta($post_arr['id'], 'hd_video', true);
                    // Pastikan selalu mengembalikan 'on' atau 'off'
                    return ($value === 'on') ? 'on' : 'off';
                },
                'update_callback' => function($value, $post) {
                    $sanitized_value = $this->sanitize_hd_video($value);
                    update_post_meta($post->ID, 'hd_video', $sanitized_value);
                },
                'schema' => array(
                    'description' => 'Status video kualitas tinggi (on/off)',
                    'type' => 'string',
                    'enum' => array('on', 'off'),
                    'context' => array('view', 'edit'),
                ),
            ));
            
            // Register field untuk tracking_url
            register_rest_field($post_type, 'tracking_url', array(
                'get_callback' => function($post_arr) {
                    return get_post_meta($post_arr['id'], 'tracking_url', true);
                },
                'update_callback' => function($value, $post) {
                    update_post_meta($post->ID, 'tracking_url', esc_url_raw($value));
                },
                'schema' => array(
                    'description' => 'URL untuk tracking',
                    'type' => 'string',
                    'context' => array('view', 'edit'),
                ),
            ));
            
            // Register field untuk embed
            register_rest_field($post_type, 'embed', array(
                'get_callback' => function($post_arr) {
                    return get_post_meta($post_arr['id'], 'embed', true);
                },
                'update_callback' => function($value, $post) {
                    update_post_meta($post->ID, 'embed', $this->sanitize_embed($value));
                },
                'schema' => array(
                    'description' => 'Kode embed (iframe atau script)',
                    'type' => 'string',
                    'context' => array('view', 'edit'),
                ),
            ));
        }
    }
}

// Inisialisasi plugin
new CustomMetadataAPIRegistrar();